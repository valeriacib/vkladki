var buttons = document.querySelectorAll('.toggle-btn');

function toggleContent(index) {
  var contents = document.querySelectorAll('.content');
  for (var i = 0; i < contents.length; i++) {
    if (i !== index) {
      contents[i].style.display = 'none';
    }
  }
  
  var content = contents[index];
  if (content.style.display === 'none') {
    content.style.display = 'block';
  } else {
    content.style.display = 'none';
  }
}

buttons.forEach(function(button, index) {
  button.addEventListener('click', function() {
    toggleContent(index);
  });
});